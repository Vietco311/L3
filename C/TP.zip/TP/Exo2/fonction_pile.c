#include "fonction_pile.h"

pile * init_pile()
{
    pile* p_nv_elt = malloc(sizeof(pile));
    p_nv_elt->val = rand() % 101;
    p_nv_elt->p_suiv = NULL;
    return p_nv_elt;
}

void test_vide(pile* p_sommet)
{
    if (p_sommet == NULL)
        printf("liste vide");
}

void empile(pile** p_p_sommet, pile* p_nv_elt)
{
    p_nv_elt->p_suiv = *p_p_sommet;
    *p_p_sommet = p_nv_elt;
}

void depile(pile** p_p_sommet)
{
    pile* n;
    if (*p_p_sommet != NULL) {
        n = *p_p_sommet;
        *p_p_sommet = (*p_p_sommet)->p_suiv;
        free(n);
    }
}

int get_sommet(pile* p_sommet)
{
    return p_sommet->val;
}

int get_sommet_depile(pile** p_sommet)
{
    int retour = (*p_sommet)->val;
    depile(p_sommet);
    return retour;
}

void reverse_list(int * tab, pile ** p_p_sommet){
    for (int i = 0; i <= sizeof(tab); i++)
    {
        pile* nouveau = malloc(sizeof(pile));
        nouveau->val = tab[i];
        nouveau->p_suiv = NULL;
        empile(p_p_sommet, nouveau);
    }
    parcourir(*p_p_sommet);
    while(*p_p_sommet != NULL){   
        tab[sizeof(tab)] = get_sommet_depile(p_p_sommet);
        printf("%d",tab[sizeof(tab)]);
    }
    parcourir(*p_p_sommet);    
}

void parcourir(pile* p_sommet)
{
    if (p_sommet == NULL)
        printf("liste vide");
    else
        while (p_sommet != NULL) {
            printf("%d--", p_sommet->val);
            p_sommet = p_sommet->p_suiv;
        }
    putchar('\n');
}
