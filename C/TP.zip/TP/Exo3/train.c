#include "train.h"

Train * init_train(Horaire * tabHoraire, int nDistance, char * nArrive, char * nDepart){
    Train * nvTrain = malloc(sizeof(Train));
    nvTrain->distance = nDistance;
    memcpy(nvTrain->villeArrive, nArrive, 12);
    memcpy(nvTrain->villeDepart, nDepart, 12);
    nvTrain->temps = tabHoraire;
    lstTrain[sizeof(lstTrain)] = nvTrain;
    return nvTrain;

}

Horaire * init_horaire(int nHeureDepart, int nMinuteDepart, int nHeureArrive, int nMinuteArrive){
    Horaire * nvHoraire = malloc(sizeof(Horaire));
    sprintf(nvHoraire->depart, "%d:%d", nHeureDepart, nMinuteDepart);
    sprintf(nvHoraire->arrive, "%d:%d", nHeureArrive, nMinuteArrive);
    return nvHoraire;
}

void villeDepart(Train * p_train, char * depart){
    while(p_train != NULL){
        if(p_train->villeDepart == depart){
            printf("%s, %s,%s,%d Km",(p_train)->villeDepart,(p_train)->villeArrive,(p_train)->temps->depart,(p_train)->temps->arrive , (p_train)->distance);
        }
    }
}

int calculVitesse(char * arrive, char * depart, int longueur){
    char delim[] = ":";
	char * tDepart = strtok(depart, delim);
    int tSecDep = atoi(tDepart)*3600;
	tDepart = strtok(NULL, delim);
    tSecDep += atoi(tDepart)*60;
    char * tArrive = strtok(arrive, delim);
    int tSecArr = atoi(tArrive)*3600;
	tArrive = strtok(NULL, delim);
    tSecArr += atoi(tArrive)*60;
    int secDiff = tSecArr - tSecDep;
    int vitesse = (int)longueur*1000/secDiff;
    return vitesse;
}

Horaire * triHoraire(Train *p_train){
    lstHoraire = malloc(10*sizeof(char));
    int i = 0;
    while(p_train != NULL){
        int tSecDep = toSecond(p_train->temps->depart);
        for(int j = 0; j < sizeof(lstHoraire); j++){
            if(tSecDep < toSecond(lstHoraire[j])){
                lstHoraire[j] =  p_train->temps->depart;
            }
            printf("%s", lstHoraire[j]);
        }
        i += 1;
        p_train = lstTrain[i];
    }
}

int toSecond(char * heure){
    char delim[] = ":";
    char * temps = strtok(heure, delim);
    int toSec = atoi(temps)*3600;
    temps = strtok(NULL, delim);
    toSec += atoi(temps)*60;
    return toSec;
}