/* Selon moi la meilleure structure de donnée pour représenter cet exercice
est un arbre de struct(tel un dictionnaire) qui permettrait stocké de stocké
toutes les informations nécessaires correspondant à un train.
*/
#include "train.h"


int main(int argc, char const *argv[])
{
    Train* lstTrain[] = {};
    char ** lstHoraire = NULL;
    Horaire * h1 = init_horaire(8, 0, 8, 59);
    Train * t1 = init_train(h1, 237, "Paris", "Lille");
    Horaire * h2 = init_horaire(7, 0, 10, 59);
    Train * t2 = init_train(h2, 709, "Paris", "Lille");
    villeDepart()
    return 0;
}
