#ifndef __train_h__
#define __train_h__
 

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct horaire{
    char depart[6];
    char arrive[6];  
}Horaire;

typedef struct train{
    char villeArrive[12];
    char villeDepart[12];
    Horaire * temps;
    int distance;
}Train;

Train * init_train(Horaire * tabHoraire, int nDistance, char * nArrive, char * nDepart);

Horaire * init_horaire(int nHeureDepart, int nMinuteDepart, int nHeureArrive, int nMinuteArrive);

void villeDepart(Train * p_train, char * depart);

int calculVitesse(char * arrive, char * depart, int longueur);

Horaire * triHoraire(Train *p_train);

int toSecond(char * heure);

#endif
